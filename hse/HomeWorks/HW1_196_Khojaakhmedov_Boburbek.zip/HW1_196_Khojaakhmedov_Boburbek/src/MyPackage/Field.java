/**
 * @author <a href="mailto:bbkhozhaakhmedov_1@edu.hse.ru"> Boburbek Khojaakhmedov</a>
 */
package MyPackage;

public abstract class Field {
    public abstract void mainAction(Gamer player);

    public abstract String getValue();

    public abstract void changeVal(String val);
}
