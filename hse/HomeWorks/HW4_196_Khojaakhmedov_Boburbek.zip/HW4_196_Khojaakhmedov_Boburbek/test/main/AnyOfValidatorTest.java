package main;

import org.junit.jupiter.api.Test;
import validation.AnyOf;
import validation.BugReportField;
import validation.Constrained;
import validation.ValidationError;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class AnyOfValidatorTest {

    @Test
    void validate() {
        AnnotationValidator vl = new AnnotationValidator();
        AnyOfClass obj = new AnyOfClass();
        Set<ValidationError> setArr = vl.validate(obj);
        List<String> list = new ArrayList<>();
        for (var el : setArr) {
            list.add(el.getMessage() + "|" + el.getPath() + "|" + el.getFailedValue());
        }
        String answer = "Value of field dont match any appropriate importance!|str|some text";
        assertTrue(list.contains(answer));
    }

    @Test
    void contains() {
        String[] value = new String[]{"1","2"};
        var rez = AnyOfValidator.contains(value,"1");
        assertTrue(rez);
    }
}

@Constrained
class AnyOfClass {
    @AnyOf({"House", "Hostel"})
    String str = "some text";
    @AnyOf({"House", "Hostel"})
    String str2 = "House";
}