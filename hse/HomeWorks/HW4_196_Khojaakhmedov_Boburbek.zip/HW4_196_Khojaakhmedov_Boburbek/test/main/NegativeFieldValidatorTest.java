package main;

import org.junit.jupiter.api.Test;
import validation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class NegativeFieldValidatorTest {

    @Test
    void validate() {
        AnnotationValidator vl = new AnnotationValidator();
        NegativeClass obj = new NegativeClass();
        Set<ValidationError> setArr = vl.validate(obj);
        List<String> list = new ArrayList<>();
        for (var el : setArr) {
            list.add(el.getMessage() + "|" + el.getPath() + "|" + el.getFailedValue());
        }
        String answer = "Value of field cannot be positive!|s|2";
        assertTrue(list.contains(answer));
    }
}
@Constrained
class NegativeClass {
    @Negative
    int age = 12;
    @Negative
    byte num = -12;
    @Negative
    long l = 2L;
    @Negative
    short s = 2;
    @Negative
    Integer age2 = 12;
    @Negative
    Byte num2 = -12;
    @Negative
    Long l2 = 2L;
    @Negative
    Short s2 = 2;
}