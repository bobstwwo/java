package main;

import org.junit.jupiter.api.Test;
import validation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class NotNullFieldValidatorTest {

    @Test
    void validate() {
        AnnotationValidator vl = new AnnotationValidator();
        NotNullClass obj = new NotNullClass();
        Set<ValidationError> setArr = vl.validate(obj);
        List<String> list = new ArrayList<>();
        for (var el : setArr) {
            list.add(el.getMessage() + "|" + el.getPath() + "|" + el.getFailedValue());
        }
        String answer = "Value of field cannot be null!|str|null";
        assertTrue(list.contains(answer));
    }
}

@Constrained
class NotNullClass {
    @NotNull
    String str;
    @NotEmpty
    int[] arr;
    @NotNull
    @AnyOf({"House", "Hostel"})
    private String propertyType;
}