package main;

import org.junit.jupiter.api.Test;
import validation.AnyOf;
import validation.Constrained;
import validation.InRange;
import validation.ValidationError;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class InRangeFieldValidatorTest {

    @Test
    void validate() {
        AnnotationValidator vl = new AnnotationValidator();
        InRangeClass obj = new InRangeClass();
        Set<ValidationError> setArr = vl.validate(obj);
        List<String> list = new ArrayList<>();
        for (var el : setArr) {
            list.add(el.getMessage() + "|" + el.getPath() + "|" + el.getFailedValue());
        }
        String answer = "Value of field might be between [5,10]!|age|12";
        assertTrue(list.contains(answer));
    }
}

@Constrained
class InRangeClass {
    @InRange(min = 5, max = 10)
    int age = 12;
    @InRange(min = 5, max = 10)
    byte num = -12;
    @InRange(min = 5, max = 10)
    long l = 2L;
    @InRange(min = 5, max = 10)
    short s = 2;
    @InRange(min = 5, max = 10)
    Integer age2 = 12;
    @InRange(min = 5, max = 10)
    Byte num2 = -12;
    @InRange(min = 5, max = 10)
    Long l2 = 2L;
    @InRange(min = 5, max = 10)
    Short s2 = 2;
}