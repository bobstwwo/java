package main;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import validation.*;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class TestClass {
    int age = 12;
    byte num = -12;
    long l = 2L;
    short s = 2;
    Integer age2 = 12;
    Byte num2 = 1;
    Long l2 = 2L;
    Short s2 = 2;
    String s3 = "1231412";
}

class PositiveFieldValidatorTest {
    @Test
    void validate() {
        TestClass testClass = new TestClass();
        var bugField = new BugReportField("Value of field cannot be negative!","", -12);
        var posFieldVal = new PositiveFieldValidator();
        Class<?> objectClass = TestClass.class;
        Field[] fields = objectClass.getDeclaredFields();

        assertEquals(null, posFieldVal.validate(testClass, fields[0], true));
        assertEquals(null, posFieldVal.validate(testClass, fields[2], true));
        assertEquals(null, posFieldVal.validate(testClass, fields[3], true));
        assertEquals(null, posFieldVal.validate(testClass, fields[4], true));
        assertEquals(null, posFieldVal.validate(testClass, fields[5], true));
        assertEquals(null, posFieldVal.validate(testClass, fields[6], true));


        AnnotationValidator vl = new AnnotationValidator();
        PositiveClass obj = new PositiveClass();
        Set<ValidationError> setArr = vl.validate(obj);
        List<String> list = new ArrayList<>();
        for (var el : setArr) {
            list.add(el.getMessage() + "|" + el.getPath() + "|" + el.getFailedValue());
        }
        String answer = "Value of field cannot be negative!|age2|-12";
        assertTrue(list.contains(answer));
    }

    @Test
    void validate2(){
        Long n_long = 2L;
        TestClass testClass = new TestClass();
        var bugField = new BugReportField("Value of field cannot be negative!","", -12);
        var posFieldVal = new PositiveFieldValidator();
        Class<?> objectClass = TestClass.class;
        Field[] fields = objectClass.getDeclaredFields();
        assertEquals(bugField.toString(), posFieldVal.validate(testClass, fields[1], true).toString());
    }
}

@Constrained
class PositiveClass {
    @Positive
    int age = -12;
    @Positive
    byte num = -12;
    @Positive
    long l = -2L;
    @Positive
    short s = -2;
    @Positive
    Integer age2 = -12;
    @Positive
    Byte num2 = -1;
    @Positive
    Long l2 = -2L;
    @Positive
    Short s2 = -2;
}













