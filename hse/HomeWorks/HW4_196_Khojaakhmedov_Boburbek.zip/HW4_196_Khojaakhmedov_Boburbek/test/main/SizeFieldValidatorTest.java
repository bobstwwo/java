package main;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import validation.*;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class AnyClass {
    @Size(min = 1, max = 5)
    private int[] arr = new int[]{1, 2, 34};
    private List<Size> arr2;
    private String s3 = "1231412";
}

class SizeFieldValidatorTest {

    AnyClass testClass = new AnyClass();
    TestClass testClass2 = new TestClass();
    BugReportField bugField = new BugReportField("Value of field cannot be negative!", "", -12);
    SizeFieldValidator objValidator = new SizeFieldValidator();
    Class<?> objectClass = AnyClass.class;
    Class<?> objectClass2 = TestClass.class;
    Field[] fields = objectClass.getDeclaredFields();
    Field[] fields2 = objectClass2.getDeclaredFields();

    @Test
    void validate() {
        assertEquals(null, objValidator.validate(testClass2, fields2[0], true));
        assertEquals(null, objValidator.validate(testClass2, fields2[7], true));
        assertEquals(null, objValidator.validate(testClass, fields[0], true));
        Assertions.assertThrows(NullPointerException.class, () -> objValidator.validate(testClass, fields[1], false));


        AnnotationValidator vl = new AnnotationValidator();
        SizeClass obj = new SizeClass();
        Set<ValidationError> setArr = vl.validate(obj);
        List<String> list = new ArrayList<>();
        for (var el : setArr) {
            list.add(el.getMessage() + "|" + el.getPath() + "|" + el.getFailedValue());
        }
        String answer = "Size of the Collection might be [1,5]!|list|[]";
        assertTrue(list.contains(answer));
    }
}

@Constrained
class SizeClass {
    @NotNull
    @Size(min = 1, max = 5)
    private List<@NotNull String> list = new ArrayList<>();
    void anyMethod(){
        list.add("Geeks");
        list.add("for");
        list.add("Geeks");
        list.add("Geeks");
        list.add("Geeks");
        list.add("Geeks");
        list.add("Geeks");
    }
}