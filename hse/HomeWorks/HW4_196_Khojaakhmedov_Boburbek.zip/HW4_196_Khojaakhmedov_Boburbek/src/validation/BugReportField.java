package validation;

public class BugReportField implements ValidationError {
    private final String message;
    private final String path;
    private final Object fieldValue;

    public BugReportField(String message, String path, Object fieldValue) {
        this.message = message;
        this.path = path;
        this.fieldValue = fieldValue;
    }

    @Override
    public String getMessage() {
        return message;
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public Object getFailedValue() {
        return fieldValue;
    }

    @Override
    public String toString() {
        return "BugReportField{" +
                "message='" + message + '\'' +
                ", path='" + path + '\'' +
                ", fieldValue=" + fieldValue +
                '}';
    }
}
