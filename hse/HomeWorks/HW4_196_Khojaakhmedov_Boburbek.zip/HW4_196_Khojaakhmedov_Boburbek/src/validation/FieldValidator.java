package validation;

import java.lang.reflect.Field;

public interface FieldValidator {
    BugReportField validate(Object obj, Field field,boolean depth);
}
