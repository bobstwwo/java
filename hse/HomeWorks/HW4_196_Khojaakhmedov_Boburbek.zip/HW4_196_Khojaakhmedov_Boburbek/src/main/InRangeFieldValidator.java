package main;

import validation.BugReportField;
import validation.FieldValidator;
import validation.InRange;

import java.lang.reflect.Field;

public class InRangeFieldValidator implements FieldValidator {
    @Override
    public BugReportField validate(Object obj, Field field, boolean depth) {
        if (int.class.isAssignableFrom(field.getType()) || Integer.class.isAssignableFrom(field.getType())) {
            try {
                long min = field.getAnnotatedType().getAnnotation(InRange.class).min();
                long max = field.getAnnotatedType().getAnnotation(InRange.class).max();
                int valField = (int) field.get(obj);
                if (!(valField >= min && valField <= max)) {
                    return new BugReportField("Value of field might be between [" + min + "," + max + "]!", AnnotationValidator.path, valField);
                }
            } catch (IllegalAccessException msg) {
                throw new ValidateException(msg.getMessage(), msg);
            }
        }
        if (long.class.isAssignableFrom(field.getType()) || Long.class.isAssignableFrom(field.getType())) {
            try {
                long min = field.getAnnotatedType().getAnnotation(InRange.class).min();
                long max = field.getAnnotatedType().getAnnotation(InRange.class).max();
                long valField = (long) field.get(obj);
                if (!(valField >= min && valField <= max)) {
                    return new BugReportField("Value of field might be between [" + min + "," + max + "]!", AnnotationValidator.path, valField);
                }
            } catch (IllegalAccessException msg) {
                throw new ValidateException(msg.getMessage(), msg);
            }
        }
        if (byte.class.isAssignableFrom(field.getType()) || Byte.class.isAssignableFrom(field.getType())) {
            try {
                long min = field.getAnnotatedType().getAnnotation(InRange.class).min();
                long max = field.getAnnotatedType().getAnnotation(InRange.class).max();
                byte valField = (byte) field.get(obj);
                if (!(valField >= min && valField <= max)) {
                    return new BugReportField("Value of field might be between [" + min + "," + max + "]!", AnnotationValidator.path, valField);
                }
            } catch (IllegalAccessException msg) {
                throw new ValidateException(msg.getMessage(), msg);
            }
        }
        if (short.class.isAssignableFrom(field.getType()) || Short.class.isAssignableFrom(field.getType())) {
            try {
                long min = field.getAnnotatedType().getAnnotation(InRange.class).min();
                long max = field.getAnnotatedType().getAnnotation(InRange.class).max();
                short valField = (short) field.get(obj);
                if (!(valField >= min && valField <= max)) {
                    return new BugReportField("Value of field might be between [" + min + "," + max + "]!", AnnotationValidator.path, valField);
                }
            } catch (IllegalAccessException msg) {
                throw new ValidateException(msg.getMessage(), msg);
            }
        }
        if (depth) {
            if (obj instanceof Integer) {
                long min = field.getAnnotatedType().getAnnotation(InRange.class).min();
                long max = field.getAnnotatedType().getAnnotation(InRange.class).max();
                int valField = (int) (obj);
                if (!(valField >= min && valField <= max)) {
                    return new BugReportField("Value of field might be between [" + min + "," + max + "]!", AnnotationValidator.path, valField);
                }
            }
            if (obj instanceof Long) {
                long min = field.getAnnotatedType().getAnnotation(InRange.class).min();
                long max = field.getAnnotatedType().getAnnotation(InRange.class).max();
                long valField = (long) (obj);
                if (!(valField >= min && valField <= max)) {
                    return new BugReportField("Value of field might be between [" + min + "," + max + "]!", AnnotationValidator.path, valField);
                }
            }
            if (obj instanceof Byte) {
                long min = field.getAnnotatedType().getAnnotation(InRange.class).min();
                long max = field.getAnnotatedType().getAnnotation(InRange.class).max();
                byte valField = (byte) (obj);
                if (!(valField >= min && valField <= max)) {
                    return new BugReportField("Value of field might be between [" + min + "," + max + "]!", AnnotationValidator.path, valField);
                }
            }
            if (obj instanceof Short) {
                long min = field.getAnnotatedType().getAnnotation(InRange.class).min();
                long max = field.getAnnotatedType().getAnnotation(InRange.class).max();
                short valField = (short) (obj);
                if (!(valField >= min && valField <= max)) {
                    return new BugReportField("Value of field might be between [" + min + "," + max + "]!", AnnotationValidator.path, valField);
                }
            }
        }
        return null;
    }
}
