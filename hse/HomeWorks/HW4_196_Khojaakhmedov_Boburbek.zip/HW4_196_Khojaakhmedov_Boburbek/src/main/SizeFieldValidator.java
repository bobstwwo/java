package main;

import validation.BugReportField;
import validation.FieldValidator;
import validation.Size;

import java.lang.reflect.Field;
import java.util.Collection;

public class SizeFieldValidator implements FieldValidator {
    @Override
    public BugReportField validate(Object obj, Field field, boolean depth) {
        field.setAccessible(true);
        if (Collection.class.isAssignableFrom(field.getType())) {
            int min = field.getAnnotatedType().getAnnotation(Size.class).min();
            int max = field.getAnnotatedType().getAnnotation(Size.class).max();
            try {
                Collection<?> valField = (Collection<?>) field.get(obj);
                if (!(valField.size() >= min && valField.size() <= max)) {
                    return new BugReportField("Size of the Collection might be [" + min + "," + max + "]!", AnnotationValidator.path, valField);
                }
            } catch (IllegalAccessException msg) {
                throw new ValidateException(msg.getMessage(), msg);
            }
        }
        if (String.class.isAssignableFrom(field.getType())) {
            try {
                int min = field.getAnnotation(Size.class).min();
                int max = field.getAnnotation(Size.class).max();
                String valField = (String) field.get(obj);
                if (valField.length() >= min && valField.length() <= max) {
                    return new BugReportField("Length of the field might be [" + min + "," + max + "]!", AnnotationValidator.path, valField);
                }
            } catch (IllegalAccessException msg) {
                throw new ValidateException(msg.getMessage(), msg);
            }
        }
        if (depth) {
            if (obj instanceof Collection) {
                int min = field.getAnnotatedType().getAnnotation(Size.class).min();
                int max = field.getAnnotatedType().getAnnotation(Size.class).max();
                Collection<?> valField = (Collection<?>) (obj);
                if (!(valField.size() >= min && valField.size() <= max)) {
                    return new BugReportField("Size of the Collection might be [" + min + "," + max + "]!", AnnotationValidator.path, valField);
                }
            }
            if (obj instanceof String) {
                int min = field.getAnnotation(Size.class).min();
                int max = field.getAnnotation(Size.class).max();
                String valField = (String) (obj);
                if (valField.length() >= min && valField.length() <= max) {
                    return new BugReportField("Length of the field might be [" + min + "," + max + "]!", AnnotationValidator.path, valField);
                }
            }
        }
        return null;
    }
}
