package main;

public class ValidateException extends RuntimeException{
    public ValidateException(String errorMessage) {
        super(errorMessage);
    }

    public ValidateException(String errorMessage, Throwable err) {
        super(errorMessage, err);
    }
}
