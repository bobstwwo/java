package main;


import validation.BugReportField;
import validation.FieldValidator;

import java.lang.reflect.Field;
import java.util.Collection;

public class NotEmptyFieldValidator implements FieldValidator {
    @Override
    public BugReportField validate(Object obj, Field field, boolean depth) {
        if (Collection.class.isAssignableFrom(field.getType())) {
            try {
                Collection<?> valField = (Collection<?>) field.get(obj);
                if (!(valField == null || valField.isEmpty())) {
                    return new BugReportField("Value of field cannot be empty!", AnnotationValidator.path, valField);
                }
            } catch (IllegalAccessException msg) {
                throw new ValidateException(msg.getMessage(), msg);
            }
        }
        if (String.class.isAssignableFrom(field.getType())) {
            try {
                String valField = (String) field.get(obj);
                if (valField == null || valField.isEmpty()) {
                    return new BugReportField("Value of field cannot be empty!", AnnotationValidator.path, valField);
                }
            } catch (IllegalAccessException msg) {
                throw new ValidateException(msg.getMessage(), msg);
            }
        }
        if (depth) {
            if (obj instanceof Collection) {
                Collection<?> valField = (Collection<?>) (obj);
                if (!(valField == null || valField.isEmpty())) {
                    return new BugReportField("Value of field cannot be empty!", AnnotationValidator.path, valField);
                }
            }
            if (obj instanceof String) {
                String valField = (String) obj;
                if (valField == null || valField.isEmpty()) {
                    return new BugReportField("Value of field cannot be empty!", AnnotationValidator.path, valField);
                }
            }
        }
        return null;
    }
}
