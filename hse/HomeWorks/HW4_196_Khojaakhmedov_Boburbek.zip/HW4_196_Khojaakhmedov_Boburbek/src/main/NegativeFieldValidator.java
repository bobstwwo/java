package main;

import validation.BugReportField;
import validation.FieldValidator;

import java.lang.reflect.Field;

public class NegativeFieldValidator implements FieldValidator {
    @Override
    public BugReportField validate(Object obj, Field field, boolean depth) {
        if (long.class.equals(field.getType()) || Long.class.equals(field.getType())) {
            try {
                long valField = (long) field.get(obj);
                if (valField >= 0) {
                    return new BugReportField("Value of field cannot be positive!", AnnotationValidator.path, valField);
                }
            } catch (IllegalAccessException msg) {
                throw new ValidateException(msg.getMessage(), msg);
            }
        }
        if (int.class.equals(field.getType()) || Integer.class.equals(field.getType())) {
            try {
                int valField = (int) field.get(obj);
                if (valField >= 0) {
                    return new BugReportField("Value of field cannot be positive!", AnnotationValidator.path, valField);
                }
            } catch (IllegalAccessException msg) {
                throw new ValidateException(msg.getMessage(), msg);
            }
        }
        if (byte.class.equals(field.getType()) || Byte.class.equals(field.getType())) {
            try {
                byte valField = (byte) field.get(obj);
                if (valField >= 0) {
                    return new BugReportField("Value of field cannot be positive!", AnnotationValidator.path, valField);
                }
            } catch (IllegalAccessException msg) {
                throw new ValidateException(msg.getMessage(), msg);
            }
        }
        if (short.class.equals(field.getType()) || Short.class.equals(field.getType())) {
            try {
                short valField = (short) field.get(obj);
                if (valField >= 0) {
                    return new BugReportField("Value of field cannot be positive!", AnnotationValidator.path, valField);
                }
            } catch (IllegalAccessException msg) {
                throw new ValidateException(msg.getMessage(), msg);
            }
        }
        if (depth) {
            if (obj instanceof Long) {
                long valField = (long) obj;
                if (valField >= 0) {
                    return new BugReportField("Value of field cannot be positive!", AnnotationValidator.path, valField);
                }
            }
            if (obj instanceof Integer) {
                int valField = (int) obj;
                if (valField >= 0) {
                    return new BugReportField("Value of field cannot be positive!", AnnotationValidator.path, valField);
                }
            }
            if (obj instanceof Byte) {
                byte valField = (byte) obj;
                if (valField >= 0) {
                    return new BugReportField("Value of field cannot be positive!", AnnotationValidator.path, valField);
                }
            }
            if (obj instanceof Short) {
                short valField = (short) obj;
                if (valField >= 0) {
                    return new BugReportField("Value of field cannot be positive!", AnnotationValidator.path, valField);
                }
            }
        }
        return null;
    }
}
