package main;

import validation.BugReportField;
import validation.FieldValidator;

import java.lang.reflect.Field;

public class NotNullFieldValidator implements FieldValidator {
    @Override
    public BugReportField validate(Object obj, Field field, boolean depth) {
        try {
            var valField = field.get(obj);
            if (valField == null)
                return new BugReportField("Value of field cannot be null!", AnnotationValidator.path, valField);
        } catch (IllegalAccessException msg) {
            throw new ValidateException(msg.getMessage(), msg);
        }
        if (depth) {
            if (obj == null)
                return new BugReportField("Value of field cannot be null!", AnnotationValidator.path, obj);
        }
        return null;
    }
}
