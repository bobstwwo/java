package main;

import validation.AnyOf;
import validation.BugReportField;
import validation.FieldValidator;

import java.lang.reflect.AnnotatedParameterizedType;
import java.lang.reflect.Field;


public class AnyOfValidator implements FieldValidator {
    @Override
    public BugReportField validate(Object obj, Field field, boolean depth) {
        field.setAccessible(true);
        if (String.class.equals(field.getType())) {
            try {
                String valField = (String) field.get(obj);
                String[] value = field.getAnnotatedType().getAnnotation(AnyOf.class).value();
                if (!contains(value, valField)) {
                    return new BugReportField("Value of field dont match any appropriate importance!", AnnotationValidator.path, valField);
                }
            } catch (IllegalAccessException msg) {
                throw new ValidateException(msg.getMessage(), msg);
            }
        }
        if (depth) {
            String[] value = ((AnnotatedParameterizedType) field.getAnnotatedType()).getAnnotatedActualTypeArguments()[0].getAnnotation(AnyOf.class).value();
            if(obj instanceof String)
            {
                String valField = (String) obj;
                if (!contains(value, valField)) {
                    return new BugReportField("Value of field dont match any appropriate importance!", AnnotationValidator.path, valField);
                }
            }
        }
        return null;
    }

    public static <T> boolean contains(final T[] array, final T v) {
        for (final T e : array)
            if (e == v || v != null && v.equals(e))
                return true;

        return false;
    }
}
