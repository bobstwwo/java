package main;

import validation.*;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedParameterizedType;
import java.lang.reflect.Field;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class AnnotationValidator implements Validator {
    public static String path = "";
    private Map<Class<? extends Annotation>, FieldValidator> mapValidator = new HashMap<>();

    public AnnotationValidator() {
        mapValidator.put(AnyOf.class, new AnyOfValidator());
        mapValidator.put(InRange.class, new InRangeFieldValidator());
        mapValidator.put(Negative.class, new NegativeFieldValidator());
        mapValidator.put(NotBlank.class, new NotBlankFieldValidator());
        mapValidator.put(NotEmpty.class, new NotEmptyFieldValidator());
        mapValidator.put(NotNull.class, new NotNullFieldValidator());
        mapValidator.put(Positive.class, new PositiveFieldValidator());
        mapValidator.put(Size.class, new SizeFieldValidator());
    }

    @Override
    public Set<ValidationError> validate(Object object) {
        final String localPath = path;
        Set<ValidationError> result = new HashSet<>();
        if (object == null) {
            return result;
        }
        Class<?> objectClass = object.getClass();
        if (objectClass.isAnnotationPresent(Constrained.class)) {
            Field[] fields = objectClass.getDeclaredFields();
            ArrayList<BugReportField> bugReportFields = new ArrayList<BugReportField>();
            for (Field field : fields) {
                path = localPath + field.getName();
                field.setAccessible(true);
                Annotation[] annotations = field.getAnnotatedType().getAnnotations();
                for (Annotation annotation : annotations) {
                    if (mapValidator.get(annotation.annotationType()) != null) {
                        var tmp = mapValidator.get(annotation.annotationType()).validate(object, field, false);
                        if (tmp != null) {
                            result.add(tmp);
                        }
                    }
                }
                try {
                    var obj = field.get(object);
                    this.validate(obj);
                } catch (IllegalAccessException e) {
                    throw new ValidateException(e.getMessage());
                }
                if (List.class.isAssignableFrom(field.getType())) {
                    final String template = path;
                    try {
                        List list = (List) field.get(object);
                        for (int i = 0; i < list.size(); i++) {
                            path += "[" + i + "].";
                            result.addAll(this.validate(list.get(i)));
                            path = template;
                        }
                        var annotationsArr1 = ((AnnotatedParameterizedType) field.getAnnotatedType()).getAnnotatedActualTypeArguments()[0].getAnnotations();
                        var annotationsArr2 = field.getAnnotatedType().getAnnotations();
                        var annotations_list = Arrays.asList(annotationsArr1).stream().filter(Predicate.not(Arrays.asList(annotationsArr2)::contains)).collect(Collectors.toList());
                        for (int i = 0; i < annotations_list.size(); i++) {
                            for (int j = 0; j < list.size(); j++) {
                                if (mapValidator.get(annotations_list.get(i).annotationType()) != null) {
                                    path += "[" + j + "]";
                                    var bug = mapValidator.get(annotations_list.get(i).annotationType()).validate(list.get(j), field, true);
                                    if (bug != null) {
                                        result.add(bug);
                                    }
                                    path = template;
                                }
                            }
                        }
                    } catch (IllegalAccessException e) {
                        throw new ValidateException(e.getMessage());
                    }
                }
                path="";
            }
        }
        return result;
    }
}
