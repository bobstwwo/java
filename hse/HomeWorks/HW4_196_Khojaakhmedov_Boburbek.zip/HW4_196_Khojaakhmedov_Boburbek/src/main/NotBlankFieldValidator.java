package main;

import validation.BugReportField;
import validation.FieldValidator;

import java.lang.reflect.Field;

public class NotBlankFieldValidator implements FieldValidator {
    @Override
    public BugReportField validate(Object obj, Field field, boolean depth) {
        if (String.class.equals(field.getType())) {
            try {
                String valField = (String) field.get(obj);
                if (!(valField == null || !valField.isBlank())) {
                    return new BugReportField("Value of field cannot be blank!", AnnotationValidator.path, valField + "''");
                }
            } catch (IllegalAccessException msg) {
                throw new ValidateException(msg.getMessage(), msg);
            }
        }
        if (depth) {
            if (obj instanceof String) {
                String valField = (String) obj;
                if (!(valField == null || !valField.isBlank())) {
                    return new BugReportField("Value of field cannot be blank!", AnnotationValidator.path, valField + "''");
                }
            }
        }
        return null;
    }
}
